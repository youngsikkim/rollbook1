require 'test_helper'

class EnrollmentsHelperTest < ActionView::TestCase
end
