require 'test_helper'

class LecturesHelperTest < ActionView::TestCase
end
