module LecturesHelper
end
