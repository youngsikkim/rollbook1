require 'test_helper'

class ActindexHelperTest < ActionView::TestCase
end
