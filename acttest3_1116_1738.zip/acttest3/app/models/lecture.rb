class Lecture < ActiveRecord::Base
   belongs_to :course
end
